import React from "react";
import Login from "./Login";

function Page404() {
  return (
    <>
      <div className="col d-flex justify-content-center align-items-center " style={{marginTop:"300px"}}>
        <h1>Please Log in</h1>
      </div>
    </>
  );
}

export default Page404;
